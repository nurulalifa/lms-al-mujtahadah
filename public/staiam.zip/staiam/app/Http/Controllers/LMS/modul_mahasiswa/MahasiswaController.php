<?php

namespace App\Http\Controllers\LMS\modul_mahasiswa;

use App\Http\Controllers\Controller;
use App\Models\Dosen;
use App\Models\Jadwal;
use App\Models\Jadwal_Mahasiswa;
use App\Models\Mahasiswa;
use App\Models\Matkul;
use Illuminate\Support\Facades\DB;


use Illuminate\Http\Request;

class MahasiswaController extends Controller
{
    public function index()
    {
        $id_mahasiswa = 1;
        $mahasiswa = Mahasiswa::where('table_mahasiswa.id', $id_mahasiswa)
            ->join('table_jadwal_mahasiswa', 'table_mahasiswa.id', '=', 'table_jadwal_mahasiswa.id_mahasiswa')
            ->join('table_jadwal', 'table_jadwal_mahasiswa.id_jadwal', '=', 'table_jadwal.id')
            ->join('table_matkul', 'table_jadwal.id_matkul', '=', 'table_matkul.id') // Relasi antara jadwal dan matkul
            ->join('table_dosen', 'table_jadwal.id_dosen', '=', 'table_dosen.id') // Relasi antara jadwal dan dosen
            ->select(
                'table_mahasiswa.nama as nama_mahasiswa',
                'table_matkul.nama as nama_matkul',
                'table_matkul.kode as kode_matkul',
                'table_jadwal.hari',
                'table_jadwal.jam_m as jam_mulai',
                'table_jadwal.jam_k as jam_selesai',
                'table_dosen.nama as nama_dosen'
            )
            ->get();




        return view('backend.modul_mahasiswa.dashboard', compact('mahasiswa'));
    }
}
