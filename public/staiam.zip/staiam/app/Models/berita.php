<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class berita extends Model
{
    use HasFactory;
    protected $table = 'berita';
    public static function getberita()
    {
        return DB::table('berita')
            ->orderby('tglpublish', 'desc')
            ->take(3)
            ->get();
    }
}
