<?php $__env->startSection('content'); ?>
    <div class="col-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Input Data Dosen</h4>
                <form class="forms-sample" method="POST" action="<?php echo e(url('dosen/simpan')); ?>" enctype="multipart/form-data">
                    <form class="forms-sample" method="POST" action="<?php echo e(url('dosen/simpan')); ?>"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label  for="exampleInputName1" class="form-label">Nama</label>
                            <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="Nama"
                                name="nama" />
                        </div>
                        <div class="form-group">
                            <label  for="exampleInputName1" class="form-label">Tanggal Kelulusan</label>
                            <div>
                                <input name="tgl"class="form-control" type="date" id="html5-date-input" />
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputName1">Foto</label>
                            <input type="file" class="form-control" name="foto" id="alamat"
                                placeholder="Masukan Foto">
                            <div class="text-danger">
                                <?php $__errorArgs = ['foto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <?php echo e($message); ?>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group">
                            <label  for="exampleInputName1" class="form-label">Universitas</label>
                            <input type="text" class="form-control" id="exampleFormControlInput1"
                                placeholder="Universitas" name="univ" />
                        </div>
                        <div class="form-group">
                            <label  for="exampleInputName1" class="form-label">Email</label>
                            <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="Email"
                                name="email" />
                        </div>
                        <div class="form-group">
                            <label  for="exampleInputName1" class="form-label">Kategori</label>
                            <select name="kategori" class="form-select" id="exampleFormControlSelect1"
                                aria-label="Default select example">
                                <option>Pilih Prodi</option>
                                <option value="Teknik Informatika">Teknik Informatika</option>
                                <option value="Sistem Informasi">Sistem Informasi</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label  for="exampleInputName1" class="form-label"></label>
                            <div>
                                <button type="submit" class="btn btn-primary">Tambah</button>
                            </div>
                        </div>
                    </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('.../backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/stag8444/staiam/resources/views/backend/modul_master/dosen/form.blade.php ENDPATH**/ ?>