<?php $__env->startSection('content'); ?>
    <div class="col-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Daftar Prodi</h4>
                <p class="card-description">
                    <a href="<?php echo e(url('prodi/tambah')); ?>"> <button type="button"
                            class="btn btn-primary btn-rounded btn-fw">Tambah Data</button></a>
                </p>
                <div class="table">
                    <table id="table" class="table table-striped">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Kode Prodi</th>
                                <th>Nama Prodi</th>
                                <th>Option</th>
                                
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td>
                                    <?php echo e($data->kode_prodi); ?>

                                 </td>
                                <td>
                                   <?php echo e($data->nama_prodi); ?>

                                </td>
                                <td>
                                    <div class="dropdown">
                                        <button type="button" class="btn btn-inverse-info btn-fw"
                                            id="dropdownMenuIconButton3" data-bs-toggle="dropdown" aria-haspopup="true"
                                            aria-expanded="false">
                                            <i class="fa fa-edit"></i>
                                        </button>
                                        <div class="dropdown-menu" aria-labelledby="dropdownMenuIconButton3">

                                            <a class="dropdown-item"
                                                href="<?php echo e(url('prodi/edit/' . $data->id)); ?>">Edit</a>
                                            <div class="dropdown-divider"></div>
                                            <a class="dropdown-item"
                                                href="<?php echo e(url('prodi/delete/' . $data->id)); ?>">Delete</a>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('../backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/stag8444/staiam/resources/views/backend/modul_master/prodi/daftar.blade.php ENDPATH**/ ?>