<?php $__env->startSection('content'); ?>
    <div class="row mb-5">
        <?php $__currentLoopData = $jadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-6 col-lg-4 mb-3">
            <div class="card h-100">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($j->id_matkul); ?></h5>

                    <img class="img-fluid d-flex mx-auto my-4" src="../assets/img/elements/4.jpg" alt="Card image cap" />
                    <h6 class="card-subtitle text-muted"><?php echo e($j->hari); ?></h6>
                    <p class="card-text"><?php echo e($j->jam_m); ?> - <?php echo e($j->jam_k); ?></p>
                    <a href="<?php echo e(url('input/rps/'.$j->id)); ?>" class="card-link">Input RPS</a>
                    <a href="<?php echo e(url('dosen/jadwal/'.$j->id)); ?>" class="card-link">Kelas</a>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('../backenddosen', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/stag8444/staiam/resources/views/backend/moduldosen/kelas/daftar.blade.php ENDPATH**/ ?>