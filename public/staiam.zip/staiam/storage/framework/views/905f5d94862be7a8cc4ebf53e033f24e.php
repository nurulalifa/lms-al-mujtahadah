<h1>Tes blade</h1>
<?php /**PATH D:\D'WIN IT SOLUTION\STAI AL-MUJTAHADAH\lms\resources\views/Web/Dashboard.blade.php ENDPATH**/ ?>