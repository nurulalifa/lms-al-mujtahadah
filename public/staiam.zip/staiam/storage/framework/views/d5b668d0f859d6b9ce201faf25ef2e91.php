<?php $__env->startSection('content'); ?>
<div class="col-12 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
        <h4 class="card-title">Input Ruangan</h4>
        <form class="forms-sample" method="POST" action="<?php echo e(url('ruangan/simpan')); ?>">
            <?php echo csrf_field(); ?>
          <div class="form-group">
            <label for="exampleInputName1">Nama Ruangan</label>
            <input type="text" name="nama" class="form-control" id="exampleInputName1" placeholder="Nama Ruangan">
          </div>
          <button type="submit" class="btn btn-primary me-2">Submit</button>
          <button class="btn btn-light">Cancel</button>
        </form>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('../backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/stag8444/staiam/resources/views/backend/modul_master/ruangan/tambah.blade.php ENDPATH**/ ?>