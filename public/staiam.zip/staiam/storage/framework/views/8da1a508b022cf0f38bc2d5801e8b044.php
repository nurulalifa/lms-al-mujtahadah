<?php $__env->startSection('content'); ?>
    <div class="col-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Input Mata Kuliah</h4>
                <form class="forms-sample" method="POST" action="<?php echo e(url('matkul/simpan')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="exampleInputName1">Nama Mata Kuliah</label>
                        <input type="text" name="nama" class="form-control" id="exampleInputName1" placeholder="Nama Matakuliah">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputName1">Kode Mata Kuliah</label>
                        <input type="text" name="kode" class="form-control" id="exampleInputName1" placeholder="Kode Matakuliah">
                    </div>
                    <div class="form-group">
                        <label for="exampleFormControlSelect1" class="form-label">Dosen Pengampu</label>
                        <select name="id_dosen" class="form-select" id="exampleFormControlSelect1"
                            aria-label="Default select example">
                            <option>Pilih Dosen</option>
                            <?php $__currentLoopData = $dosen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($d->id); ?>"><?php echo e($d->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputName1">Bobot Matakuliah</label>
                        <input type="text" name="bobot" class="form-control" id="exampleInputName1" placeholder="Bobot Matakuliah">
                    </div>
                    <div class="form-group">
                        <label for="exampleFormControlSelect1" class="form-label">Ruangan </label>
                        <select name="id_dosen" class="form-select" id="exampleFormControlSelect1"
                            aria-label="Default select example">
                            <option>Pilih Ruangan</option>
                            <?php $__currentLoopData = $ruangan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($r->id); ?>"><?php echo e($d->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary mr-2">Submit</button>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('../backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/stag8444/staiam/resources/views/backend/modul_master/matakuliah/tambah.blade.php ENDPATH**/ ?>