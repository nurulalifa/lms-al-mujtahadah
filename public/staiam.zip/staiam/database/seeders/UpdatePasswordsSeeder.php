<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;

class UpdatePasswordsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Mengambil semua pengguna dari database
        $user = DB::table('user')->get();

        foreach ($user as $user) {
            // Asumsikan password asli tidak tersedia dan menggunakan password default
            $newPasswordHash = Hash::make('12345'); // Gantilah 'password_default' dengan password default jika perlu

            // Memperbarui password dengan hash Bcrypt
            DB::table('user')
                ->where('email', $user->email)
                ->update(['password' => $newPasswordHash]);
        }
    }
}
